/**
 * @author Denise Martinez, Nhi Pham
 * A program that allows the user to encrypt or decrypt
 * messages using two different types of encryption methods.
 * It asks the user whether they want to encrypt or decrypt a 
 * message and to choose an encryption type, Atbash or 
 * Caesar, if they choose Caesar, prompt them for a shift
 * amount (1-25). Encrypts the message and writes it to a file
 * called 'message.txt' (leaves any space or punctuation the same)
 * If they choose to decrypt, prompts them to choose a decryption
 * type, and a shift amount if they choose Caesar. Decrypt the 
 * message read in from the 'message.txt' file and displays it
 * to the screen.
 */
import java.util.Scanner;
import java.io.*;  	

public class Main 
{
	/**
	 * Displays menu to let user choose to encrypt
	 * or decrypt a message
	 * @return user's valid choice
	 */
	public static int mainMenu()
	{
		int choice = 0;
		System.out.println();
		System.out.println( "Secret Decoder Ring " );
		System.out.println( "1. Encrypt" );
		System.out.println( "2. Decrypt" );
		choice = CheckInput.getIntRange(1, 2);
		return choice;
	}
	
	/**
	 * Displays menu to let user choose encryption or
	 * decryption type
	 * @return user's valid choice
	 */
	public static int typeMenu()
	{
		int choice = 0;
		System.out.println( "1. Atbash" );
		System.out.println( "2. Caesar" );
		choice = CheckInput.getIntRange(1, 2);
		return choice;
	}
	
	/**
	 * Writes encrypted message to "message.txt"
	 * @param msg encrypted message
	 */
	public static void writeFile( String msg )
	{
		//passes file to file object
		try 
	    {
			PrintWriter writer = new PrintWriter( new File( "message.txt") );
			writer.println( msg );
			writer.close();
		}
	    catch( FileNotFoundException fnf ) 
	    {  
	    	System.out.println("File was not found.");
	    }
	}
	
	/**
	 * Reads from "message.txt"
	 * @return encrypted message located in "message.txt"
	 */
	public static String readFile() 
	{
		String msg = "";
		try 
	    {
			Scanner read = new Scanner( new File( "message.txt") );
			while( read.hasNext() )
			{
				msg = read.nextLine();
	        }
			read.close();
		}
	    catch( FileNotFoundException fnf ) 
	    {  
	    	System.out.println("File was not found.");
	    }
		return msg;
	}
	
	public static void main(String[] args) 
	{
		// lets user choose to decrypt or encrypt
		int choice = mainMenu();
		// Encryption
		if( choice == 1)
		{
			// choosing type of encryption
			System.out.println( "Enter Encryption Type: ");
			int encryptionChoice = typeMenu();
			// encryption choice is Atbash
			if( encryptionChoice == 1 )
			{
				// getting message to encrypt
				System.out.println( "Enter message: ");
				String msg = CheckInput.getString();
				msg = msg.toUpperCase();
				// initializing Atbash cipher
				AtbashCipher atbash = new AtbashCipher();
				String atbashMsg = atbash.encrypt( msg );
				// writing encryption to 'message.txt'
				writeFile( atbashMsg );
				System.out.println( "Encrypted message saved to 'message.txt'.");
			}
			// encryption choice is Caesar
			if ( encryptionChoice == 2 )
			{
				// getting message to encrypt
				System.out.println( "Enter message: ");
				String msg = CheckInput.getString();
				msg = msg.toUpperCase();
				//getting shift from user
				System.out.println( "Enter shift value: ");
				int shift = CheckInput.getIntRange( 1, 25 );
				// initializing Caesar cipher
				CaesarCipher caesar = new CaesarCipher( shift );
				String caesarMsg = caesar.encrypt( msg );
				// writing encryption to 'message.txt'
				writeFile( caesarMsg );
				System.out.println( "Encrypted message saved to 'message.txt'.");
			}
		}
		// Decryption
		if( choice == 2 )
		{
			// choosing type of decryption
			System.out.println( "Enter Decryption Type: ");
			int decryptChoice = typeMenu();
			// decryption choice is Atbash
			if( decryptChoice == 1 )
			{
				// getting message to decrypt
				String msg = readFile();
				// initializing Atbash cipher
				AtbashCipher atbash = new AtbashCipher();
				String atbashAnswer = atbash.decrypt( msg );
				System.out.println( "Reading encrypted message from 'message.txt'.");
				System.out.println( "Decrypted Message: " + atbashAnswer );
			}
			// decryption choice is Caesar
			if( decryptChoice == 2 )
			{
				// getting message to decrypt
				String msg = readFile();
				System.out.println( "Reading encrypted message from 'message.txt'.");
				// getting shift from user
				System.out.println( "Enter shift value: ");
				int shift = CheckInput.getIntRange( 1, 25 );
				// initializing Caesar cipher
				CaesarCipher caesar = new CaesarCipher( shift );
				String caesarAnswer = caesar.decrypt( msg );
				System.out.println( "Decrypted Message: " + caesarAnswer );
			}
		}
	}
}
