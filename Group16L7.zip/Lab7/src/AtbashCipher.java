/**
 * @author Denise Martinez, Nhi Pham
 * Atbash cipher class which extends the abstract Cipher class
 */
public class AtbashCipher extends Cipher
{
	//instance variable
	private char[] cipherbet;
	
	/**
	 * Constructor that construct cipherbet 
	 * which is the alphabet backwards
	 */
	public AtbashCipher()
	{
		cipherbet = new char[26];
		for(int i = 0; i < 26; i++)
		{
			//using ASCII code to typecast an integer to a character
			cipherbet[i] = (char)( 90 - i );
		}
	}
	
	/**
	 * Gets letter of the same index in the cipherbet
	 * @return letter at index i of the cipherbet
	 */
	@Override
	public char getLetter( int i ) 
	{
		return cipherbet[i];
	}
}
