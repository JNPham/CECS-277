/**
 * @author Denise Martinez, Nhi Pham
 * Caesar cipher class which extends abstract Cipher class
 */
public class CaesarCipher extends Cipher
{
	//instance variable
	private char[] cipherbet;
	
	/**
	 * Constructor which constructs cipherbet with a given shift
	 * @param s shift applied to alphabet list
	 */
	public CaesarCipher( int s )
	{
		cipherbet = new char[26];
		for(int i = 0; i < 26; i++)
		{
			//loops through alphabet and shifts each character 
			cipherbet[i] = getAlphabet()[ (i + s) % 26];
		}
	}
	
	/**
	 * Gets letter of the same index in the cipherbet
	 * @return letter at index i of the cipherbet
	 */
	@Override
	public char getLetter( int i ) 
	{
		return cipherbet[i];
	}
}
