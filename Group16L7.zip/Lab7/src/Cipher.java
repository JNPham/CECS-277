/**
 * @author Denise Martinez, Nhi Pham
 * Abstract cipher class which has encrypt and decrypt methods
 */
public abstract class Cipher 
{
	//instance variable
	private char[] alphabet;
	
	/**
	 * Cipher constructor, creates list of the alphabet
	 * with capital letters
	 */
	public Cipher() 
	{
		alphabet = new char[26];
		for( int i = 0; i < 26; i++ )
		{
			//using ASCII code to typecast an integer to a character
			alphabet[i] = (char)(65 + i);
		}
	}
	
	/**
	 * Accessor method to get alphabet array
	 * @return alphabet character array
	 */
	public char[] getAlphabet()
	{
		return alphabet;
	}
	
	/**
	 * Loops through message and calls encryptLetter
	 * for each character in the string
	 * @param msg message to encrypt
	 * @return encrypted message
	 */
	public String encrypt( String msg )
	{
		String encryption = "";
		for( int i = 0; i < msg.length(); i++ )
		{
			char c = msg.charAt(i);
			// checking if character of string is a character
			if (Character.isLetter(c))
			{
				encryption += encryptLetter( c );
			}
			else
			{
				encryption += c;
			}
		}
		return encryption;

	}
	
	/**
	 * Loops through message and calls decryptLetter
	 * for each character in the string
	 * @param msg message to decrypt
	 * @return decrypted message
	 */
	public String decrypt( String msg )
	{
		String decryption = "";
		
		for( int i = 0; i < msg.length(); i++ )
		{
			char c = msg.charAt(i);
			// checking if character of string is a character
			if (Character.isLetter(c))
			{
				decryption += decryptLetter( c );
			}
			else
			{
				decryption += c;
			}
		}
		return decryption;
	}
	
	/**
	 * Calls getLetter to get the letter in the cipherbet
	 * at the specified index
	 * @param c letter to encrypt
	 * @return letter in the cipherbet 
	 */
	public char encryptLetter( char c )
	{
		int alphabetIndex = 0;
		//looping through alphabet to find index of letter 
		for( int i = 0; i < 26; i++)
		{
			 if( alphabet[i] ==  c )
			 {
				 alphabetIndex = i;
			 }
		}
		//returns letter in the cipher at the specified index
		return getLetter( alphabetIndex );

	}
	
	/**
	 * Calls getLetter to get the letter in the cipherbet
	 * at the specified index
	 * @param c letter to encrypt
	 * @return letter in the cipherbet 
	 */
	public char decryptLetter( char c )
	{
		int cipherIndex = 0;
		//looping through cipherbet to find index of letter 
		for( int i = 0; i < 26; i++)
		{
			 if( getLetter(i) ==  c )
			 {
				 cipherIndex = i;
			 }
		}
		return alphabet[ cipherIndex ];
	}
	
	/**
	 * Abstract method to get letter in cipherbet 
	 * at a specified index
	 * @param i index of letter
	 * @return index of letter in cipherbet
	 */
	public abstract char getLetter( int i );
}